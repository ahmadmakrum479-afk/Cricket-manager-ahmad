package com.cricketmanager.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@Database(
    entities = [TeamEntity::class, PlayerEntity::class, MatchEntity::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class CricketDatabase : RoomDatabase() {

    abstract fun cricketDao(): CricketDao

    companion object {
        private const val DATABASE_NAME = "cricket_manager.db"

        @Volatile
        private var INSTANCE: CricketDatabase? = null

        fun getInstance(context: Context): CricketDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { instance ->
                    INSTANCE = instance
                }
            }
        }

        private fun buildDatabase(appContext: Context): CricketDatabase {
            return Room.databaseBuilder(
                appContext,
                CricketDatabase::class.java,
                DATABASE_NAME
            )
                .addCallback(SeedDatabaseCallback { getInstance(appContext) })
                .build()
        }
    }

    private class SeedDatabaseCallback(
        private val databaseProvider: () -> CricketDatabase
    ) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                val dao = databaseProvider().cricketDao()
                val now = System.currentTimeMillis()

                val dhakaId = dao.insertTeam(
                    TeamEntity(
                        name = "Dhaka Strikers",
                        shortCode = "DHS",
                        homeGround = "Sher-e-Bangla Stadium",
                        matchesPlayed = 6,
                        wins = 4,
                        losses = 2,
                        createdAt = now - 86_400_000L
                    )
                )

                val chattogramId = dao.insertTeam(
                    TeamEntity(
                        name = "Chattogram Mariners",
                        shortCode = "CHM",
                        homeGround = "Zahur Ahmed Stadium",
                        matchesPlayed = 6,
                        wins = 3,
                        losses = 3,
                        createdAt = now - 86_400_000L
                    )
                )

                val starterPlayers = listOf(
                    PlayerEntity(
                        teamId = dhakaId,
                        name = "Tamim Rahman",
                        jerseyNumber = 28,
                        role = PlayerRole.BATTER,
                        battingStyle = "Left-hand bat",
                        bowlingStyle = "Right-arm offbreak",
                        matches = 6,
                        runs = 264,
                        wickets = 0,
                        isCaptain = true
                    ),
                    PlayerEntity(
                        teamId = dhakaId,
                        name = "Shakib Hasan",
                        jerseyNumber = 75,
                        role = PlayerRole.ALL_ROUNDER,
                        battingStyle = "Left-hand bat",
                        bowlingStyle = "Slow left-arm orthodox",
                        matches = 6,
                        runs = 198,
                        wickets = 9,
                        isCaptain = false
                    ),
                    PlayerEntity(
                        teamId = dhakaId,
                        name = "Taskin Ahmed",
                        jerseyNumber = 3,
                        role = PlayerRole.BOWLER,
                        battingStyle = "Left-hand bat",
                        bowlingStyle = "Right-arm fast",
                        matches = 6,
                        runs = 24,
                        wickets = 11,
                        isCaptain = false
                    ),
                    PlayerEntity(
                        teamId = chattogramId,
                        name = "Litton Das",
                        jerseyNumber = 16,
                        role = PlayerRole.WICKET_KEEPER,
                        battingStyle = "Right-hand bat",
                        bowlingStyle = "None",
                        matches = 6,
                        runs = 242,
                        wickets = 0,
                        isCaptain = true
                    ),
                    PlayerEntity(
                        teamId = chattogramId,
                        name = "Mehidy Miraz",
                        jerseyNumber = 53,
                        role = PlayerRole.ALL_ROUNDER,
                        battingStyle = "Right-hand bat",
                        bowlingStyle = "Right-arm offbreak",
                        matches = 6,
                        runs = 155,
                        wickets = 8,
                        isCaptain = false
                    ),
                    PlayerEntity(
                        teamId = chattogramId,
                        name = "Mustafizur Rahman",
                        jerseyNumber = 90,
                        role = PlayerRole.BOWLER,
                        battingStyle = "Left-hand bat",
                        bowlingStyle = "Left-arm fast-medium",
                        matches = 6,
                        runs = 12,
                        wickets = 10,
                        isCaptain = false
                    )
                )
                starterPlayers.forEach { dao.insertPlayer(it) }

                dao.insertMatch(
                    MatchEntity(
                        teamAName = "Dhaka Strikers",
                        teamBName = "Chattogram Mariners",
                        venue = "Mirpur Ground",
                        oversLimit = 20,
                        teamAScore = 168,
                        teamAWickets = 5,
                        teamAOvers = "20.0",
                        teamBScore = 112,
                        teamBWickets = 3,
                        teamBOvers = "13.2",
                        status = MatchStatus.LIVE,
                        resultSummary = "Chattogram Mariners need 57 runs in 40 balls",
                        scheduledAt = now
                    )
                )

                dao.insertMatch(
                    MatchEntity(
                        teamAName = "Chattogram Mariners",
                        teamBName = "Sylhet Royals",
                        venue = "Sylhet International Ground",
                        oversLimit = 20,
                        status = MatchStatus.UPCOMING,
                        resultSummary = "Scheduled T20 fixture",
                        scheduledAt = now + 86_400_000L
                    )
                )
            }
        }
    }
}
