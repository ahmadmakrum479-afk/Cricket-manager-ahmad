package com.cricketmanager.app.data.local

enum class PlayerRole(val label: String) {
    BATTER("Batter"),
    BOWLER("Bowler"),
    ALL_ROUNDER("All-Rounder"),
    WICKET_KEEPER("Wicket-Keeper")
}
