package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerRole
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TeamWithPlayers

@Composable
fun SquadScreen(
    teamsWithPlayers: List<TeamWithPlayers>,
    onAddRuns: (Long, Int) -> Unit,
    onAddWicket: (Long) -> Unit,
    onDeletePlayer: (Long) -> Unit
) {
    var selectedTeamId by remember { mutableLongStateOf(0L) }

    val displayedPlayers = remember(teamsWithPlayers, selectedTeamId) {
        if (selectedTeamId == 0L) {
            teamsWithPlayers.flatMap { it.sortedSquad }
        } else {
            teamsWithPlayers.firstOrNull { it.team.id == selectedTeamId }?.sortedSquad.orEmpty()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedTeamId == 0L,
                onClick = { selectedTeamId = 0L },
                label = { Text("All Squads") }
            )
            teamsWithPlayers.forEach { entry ->
                FilterChip(
                    selected = selectedTeamId == entry.team.id,
                    onClick = { selectedTeamId = entry.team.id },
                    label = { Text(entry.team.shortCode) }
                )
            }
        }

        if (displayedPlayers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No players in this squad yet. Tap + to add a player.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(displayedPlayers, key = { it.id }) { player ->
                    PlayerCard(
                        player = player,
                        onAddRuns = { runs -> onAddRuns(player.id, runs) },
                        onAddWicket = { onAddWicket(player.id) },
                        onDelete = { onDeletePlayer(player.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayerCard(
    player: PlayerEntity,
    onAddRuns: (Int) -> Unit,
    onAddWicket: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "#${player.jerseyNumber} ${player.name}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (player.isCaptain) {
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = "Captain",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Text(
                        text = "${player.role.label} · ${player.battingStyle}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${player.runs} Runs · ${player.wickets} Wickets",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Delete player"
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(onClick = { onAddRuns(4) }, modifier = Modifier.weight(1f)) {
                    Text("+4 Runs")
                }
                FilledTonalButton(onClick = { onAddRuns(6) }, modifier = Modifier.weight(1f)) {
                    Text("+6 Runs")
                }
                OutlinedButton(onClick = onAddWicket, modifier = Modifier.weight(1f)) {
                    Text("+1 Wkt")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPlayerSheet(
    teams: List<TeamEntity>,
    onDismiss: () -> Unit,
    onCreate: (
        teamId: Long,
        name: String,
        jersey: Int,
        role: PlayerRole,
        batting: String,
        isCaptain: Boolean
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTeamId by remember { mutableLongStateOf(teams.firstOrNull()?.id ?: 0L) }
    var name by remember { mutableStateOf("") }
    var jerseyText by remember { mutableStateOf("10") }
    var role by remember { mutableStateOf(PlayerRole.BATTER) }
    var battingStyle by remember { mutableStateOf("Right-hand bat") }
    var isCaptain by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Add Squad Player",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            if (teams.isEmpty()) {
                Text(
                    text = "Create a team in the Teams tab first before adding players.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    teams.forEach { team ->
                        FilterChip(
                            selected = selectedTeamId == team.id,
                            onClick = { selectedTeamId = team.id },
                            label = { Text(team.name) }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Player Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = jerseyText,
                onValueChange = { jerseyText = it.filter { ch -> ch.isDigit() } },
                label = { Text("Jersey Number") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = battingStyle,
                onValueChange = { battingStyle = it },
                label = { Text("Batting Style") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PlayerRole.entries.forEach { item ->
                    FilterChip(
                        selected = role == item,
                        onClick = { role = item },
                        label = { Text(item.label) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Team Captain", style = MaterialTheme.typography.bodyMedium)
                Switch(checked = isCaptain, onCheckedChange = { isCaptain = it })
            }

            Button(
                onClick = {
                    onCreate(
                        selectedTeamId,
                        name,
                        jerseyText.toIntOrNull() ?: 10,
                        role,
                        battingStyle,
                        isCaptain
                    )
                },
                enabled = teams.isNotEmpty() && name.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Save Player")
            }
        }
    }
}
