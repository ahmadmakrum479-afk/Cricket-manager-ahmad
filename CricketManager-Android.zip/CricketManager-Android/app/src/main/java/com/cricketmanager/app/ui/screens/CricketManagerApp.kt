package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.SportsCricket
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cricketmanager.app.viewmodel.CricketViewModel

enum class ManagerTab(val label: String) {
    MATCHES("Matches"),
    TEAMS("Teams"),
    SQUADS("Squads")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CricketManagerApp(viewModel: CricketViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var activeTab by remember { mutableStateOf(ManagerTab.MATCHES) }
    var showCreateSheet by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Cricket Manager",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${uiState.teamsWithPlayers.size} teams · ${uiState.players.size} players · ${uiState.matches.size} matches",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = activeTab == ManagerTab.MATCHES,
                    onClick = { activeTab = ManagerTab.MATCHES },
                    icon = { Icon(Icons.Rounded.SportsCricket, contentDescription = null) },
                    label = { Text(ManagerTab.MATCHES.label) }
                )
                NavigationBarItem(
                    selected = activeTab == ManagerTab.TEAMS,
                    onClick = { activeTab = ManagerTab.TEAMS },
                    icon = { Icon(Icons.Rounded.Groups, contentDescription = null) },
                    label = { Text(ManagerTab.TEAMS.label) }
                )
                NavigationBarItem(
                    selected = activeTab == ManagerTab.SQUADS,
                    onClick = { activeTab = ManagerTab.SQUADS },
                    icon = { Icon(Icons.Rounded.Person, contentDescription = null) },
                    label = { Text(ManagerTab.SQUADS.label) }
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateSheet = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = "Create item"
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                ManagerTab.MATCHES -> MatchesScreen(
                    matches = uiState.matches,
                    onTeamARuns = viewModel::addTeamARuns,
                    onTeamAWicket = viewModel::addTeamAWicket,
                    onTeamBRuns = viewModel::addTeamBRuns,
                    onTeamBWicket = viewModel::addTeamBWicket,
                    onCompleteMatch = viewModel::completeMatch,
                    onDeleteMatch = viewModel::deleteMatch
                )

                ManagerTab.TEAMS -> TeamsScreen(
                    teamsWithPlayers = uiState.teamsWithPlayers,
                    onDeleteTeam = viewModel::deleteTeam
                )

                ManagerTab.SQUADS -> SquadScreen(
                    teamsWithPlayers = uiState.teamsWithPlayers,
                    onAddRuns = viewModel::addRunsToPlayer,
                    onAddWicket = viewModel::addWicketToPlayer,
                    onDeletePlayer = viewModel::deletePlayer
                )
            }
        }
    }

    if (showCreateSheet) {
        when (activeTab) {
            ManagerTab.MATCHES -> AddMatchSheet(
                teams = uiState.teamsWithPlayers.map { it.team },
                onDismiss = { showCreateSheet = false },
                onCreate = { teamA, teamB, venue, overs ->
                    viewModel.createMatch(teamA, teamB, venue, overs)
                    showCreateSheet = false
                }
            )

            ManagerTab.TEAMS -> AddTeamSheet(
                onDismiss = { showCreateSheet = false },
                onCreate = { name, code, ground ->
                    viewModel.createTeam(name, code, ground)
                    showCreateSheet = false
                }
            )

            ManagerTab.SQUADS -> AddPlayerSheet(
                teams = uiState.teamsWithPlayers.map { it.team },
                onDismiss = { showCreateSheet = false },
                onCreate = { teamId, name, jersey, role, batting, isCaptain ->
                    viewModel.createPlayer(teamId, name, jersey, role, batting, isCaptain)
                    showCreateSheet = false
                }
            )
        }
    }
}
