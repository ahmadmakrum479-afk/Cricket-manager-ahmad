package com.cricketmanager.app.data.repository

import com.cricketmanager.app.data.local.CricketDao
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TeamWithPlayers
import kotlinx.coroutines.flow.Flow

class CricketRepository(private val dao: CricketDao) {

    val teamsWithPlayers: Flow<List<TeamWithPlayers>> = dao.observeTeamsWithPlayers()
    val allPlayers: Flow<List<PlayerEntity>> = dao.observeAllPlayers()
    val allMatches: Flow<List<MatchEntity>> = dao.observeAllMatches()

    suspend fun addTeam(team: TeamEntity): Long = dao.insertTeam(team)

    suspend fun deleteTeam(teamId: Long) = dao.deleteTeamById(teamId)

    suspend fun addPlayer(player: PlayerEntity): Long = dao.insertPlayer(player)

    suspend fun addRunsToPlayer(playerId: Long, runs: Int) = dao.addPlayerRuns(playerId, runs)

    suspend fun addWicketToPlayer(playerId: Long) = dao.incrementPlayerWicket(playerId)

    suspend fun deletePlayer(playerId: Long) = dao.deletePlayerById(playerId)

    suspend fun addMatch(match: MatchEntity): Long = dao.insertMatch(match)

    suspend fun updateMatchScore(
        match: MatchEntity,
        teamAScoreDelta: Int = 0,
        teamAWicketDelta: Int = 0,
        teamBScoreDelta: Int = 0,
        teamBWicketDelta: Int = 0
    ) {
        val nextAWickets = (match.teamAWickets + teamAWicketDelta).coerceIn(0, 10)
        val nextBWickets = (match.teamBWickets + teamBWicketDelta).coerceIn(0, 10)
        val nextAScore = (match.teamAScore + teamAScoreDelta).coerceAtLeast(0)
        val nextBScore = (match.teamBScore + teamBScoreDelta).coerceAtLeast(0)

        val updated = match.copy(
            teamAScore = nextAScore,
            teamAWickets = nextAWickets,
            teamBScore = nextBScore,
            teamBWickets = nextBWickets,
            status = MatchStatus.LIVE,
            resultSummary = "Live: ${match.teamAName} $nextAScore/$nextAWickets vs ${match.teamBName} $nextBScore/$nextBWickets"
        )
        dao.updateMatch(updated)
    }

    suspend fun completeMatch(match: MatchEntity) {
        val summary = when {
            match.teamAScore > match.teamBScore ->
                "${match.teamAName} won by ${match.teamAScore - match.teamBScore} runs"
            match.teamBScore > match.teamAScore ->
                "${match.teamBName} won by ${10 - match.teamBWickets} wickets"
            else -> "Match tied"
        }
        dao.updateMatch(
            match.copy(
                status = MatchStatus.COMPLETED,
                resultSummary = summary
            )
        )
    }

    suspend fun deleteMatch(matchId: Long) = dao.deleteMatchById(matchId)
}
