package com.cricketmanager.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerRole
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.repository.CricketRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CricketViewModel(private val repository: CricketRepository) : ViewModel() {

    val uiState: StateFlow<CricketUiState> = combine(
        repository.teamsWithPlayers,
        repository.allPlayers,
        repository.allMatches
    ) { teams, players, matches ->
        CricketUiState(
            teamsWithPlayers = teams,
            players = players,
            matches = matches,
            isLoaded = true
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = CricketUiState()
    )

    fun createTeam(name: String, shortCode: String, homeGround: String) {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return
        val code = shortCode.trim().uppercase().take(4).ifEmpty {
            cleanName.take(3).uppercase()
        }
        viewModelScope.launch {
            repository.addTeam(
                TeamEntity(
                    name = cleanName,
                    shortCode = code,
                    homeGround = homeGround.trim().ifEmpty { "Home Ground" }
                )
            )
        }
    }

    fun deleteTeam(teamId: Long) {
        viewModelScope.launch {
            repository.deleteTeam(teamId)
        }
    }

    fun createPlayer(
        teamId: Long,
        name: String,
        jerseyNumber: Int,
        role: PlayerRole,
        battingStyle: String,
        isCaptain: Boolean
    ) {
        val cleanName = name.trim()
        if (cleanName.isEmpty() || teamId <= 0L) return
        viewModelScope.launch {
            repository.addPlayer(
                PlayerEntity(
                    teamId = teamId,
                    name = cleanName,
                    jerseyNumber = jerseyNumber.coerceIn(1, 999),
                    role = role,
                    battingStyle = battingStyle.trim().ifEmpty { "Right-hand bat" },
                    isCaptain = isCaptain
                )
            )
        }
    }

    fun addRunsToPlayer(playerId: Long, runs: Int) {
        viewModelScope.launch {
            repository.addRunsToPlayer(playerId, runs)
        }
    }

    fun addWicketToPlayer(playerId: Long) {
        viewModelScope.launch {
            repository.addWicketToPlayer(playerId)
        }
    }

    fun deletePlayer(playerId: Long) {
        viewModelScope.launch {
            repository.deletePlayer(playerId)
        }
    }

    fun createMatch(teamA: String, teamB: String, venue: String, oversLimit: Int) {
        val a = teamA.trim()
        val b = teamB.trim()
        if (a.isEmpty() || b.isEmpty()) return
        viewModelScope.launch {
            repository.addMatch(
                MatchEntity(
                    teamAName = a,
                    teamBName = b,
                    venue = venue.trim().ifEmpty { "Local Cricket Ground" },
                    oversLimit = oversLimit.coerceIn(5, 50),
                    status = MatchStatus.UPCOMING,
                    resultSummary = "Scheduled ${oversLimit.coerceIn(5, 50)}-over match"
                )
            )
        }
    }

    fun addTeamARuns(match: MatchEntity, runs: Int) {
        viewModelScope.launch {
            repository.updateMatchScore(match = match, teamAScoreDelta = runs)
        }
    }

    fun addTeamAWicket(match: MatchEntity) {
        viewModelScope.launch {
            repository.updateMatchScore(match = match, teamAWicketDelta = 1)
        }
    }

    fun addTeamBRuns(match: MatchEntity, runs: Int) {
        viewModelScope.launch {
            repository.updateMatchScore(match = match, teamBScoreDelta = runs)
        }
    }

    fun addTeamBWicket(match: MatchEntity) {
        viewModelScope.launch {
            repository.updateMatchScore(match = match, teamBWicketDelta = 1)
        }
    }

    fun completeMatch(match: MatchEntity) {
        viewModelScope.launch {
            repository.completeMatch(match)
        }
    }

    fun deleteMatch(matchId: Long) {
        viewModelScope.launch {
            repository.deleteMatch(matchId)
        }
    }
}

class CricketViewModelFactory(
    private val repository: CricketRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CricketViewModel::class.java)) {
            return CricketViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
