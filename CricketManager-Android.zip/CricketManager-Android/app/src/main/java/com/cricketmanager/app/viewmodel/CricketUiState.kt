package com.cricketmanager.app.viewmodel

import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.TeamWithPlayers

data class CricketUiState(
    val teamsWithPlayers: List<TeamWithPlayers> = emptyList(),
    val players: List<PlayerEntity> = emptyList(),
    val matches: List<MatchEntity> = emptyList(),
    val isLoaded: Boolean = false
)
