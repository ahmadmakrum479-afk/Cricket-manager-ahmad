package com.cricketmanager.app.ui.theme

import androidx.compose.ui.graphics.Color

val PitchGreen = Color(0xFF059669)
val PitchOnGreen = Color(0xFFFFFFFF)
val PitchContainer = Color(0xFFD1FAE5)
val PitchOnContainer = Color(0xFF064E3B)

val StadiumSlate = Color(0xFF334155)
val StadiumOnSlate = Color(0xFFFFFFFF)
val StadiumContainer = Color(0xFFE2E8F0)
val StadiumOnContainer = Color(0xFF0F172A)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOutline = Color(0xFFCBD5E1)

val DarkPrimary = Color(0xFF34D399)
val DarkOnPrimary = Color(0xFF022C22)
val DarkContainer = Color(0xFF065F46)
val DarkOnContainer = Color(0xFFA7F3D0)

val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOutline = Color(0xFF334155)
