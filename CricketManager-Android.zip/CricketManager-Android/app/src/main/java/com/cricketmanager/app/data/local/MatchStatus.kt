package com.cricketmanager.app.data.local

enum class MatchStatus(val label: String) {
    UPCOMING("Upcoming"),
    LIVE("Live"),
    COMPLETED("Completed")
}
