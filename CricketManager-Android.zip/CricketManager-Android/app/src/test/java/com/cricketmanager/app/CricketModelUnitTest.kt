package com.cricketmanager.app

import com.cricketmanager.app.data.local.Converters
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.PlayerRole
import com.cricketmanager.app.data.local.TeamEntity
import com.cricketmanager.app.data.local.TeamWithPlayers
import org.junit.Assert.assertEquals
import org.junit.Test

class CricketModelUnitTest {

    private val converters = Converters()

    @Test
    fun playerRoleConversion_roundTripsCorrectly() {
        for (role in PlayerRole.entries) {
            val raw = converters.fromPlayerRole(role)
            assertEquals(role, converters.toPlayerRole(raw))
        }
    }

    @Test
    fun matchStatusConversion_roundTripsCorrectly() {
        for (status in MatchStatus.entries) {
            val raw = converters.fromMatchStatus(status)
            assertEquals(status, converters.toMatchStatus(raw))
        }
    }

    @Test
    fun teamWithPlayers_placesCaptainFirstThenJerseyOrder() {
        val team = TeamEntity(id = 1L, name = "Dhaka Strikers", shortCode = "DHS", homeGround = "Mirpur")
        val players = listOf(
            PlayerEntity(id = 1L, teamId = 1L, name = "Player 90", jerseyNumber = 90, isCaptain = false),
            PlayerEntity(id = 2L, teamId = 1L, name = "Captain 28", jerseyNumber = 28, isCaptain = true),
            PlayerEntity(id = 3L, teamId = 1L, name = "Player 3", jerseyNumber = 3, isCaptain = false)
        )
        val squad = TeamWithPlayers(team, players).sortedSquad
        assertEquals(listOf("Captain 28", "Player 3", "Player 90"), squad.map { it.name })
    }
}
