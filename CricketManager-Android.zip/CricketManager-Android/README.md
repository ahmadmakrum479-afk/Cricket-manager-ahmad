# Cricket Manager — Android App (Kotlin + Jetpack Compose + Room)

Complete Android Studio project with **Room Database**, **Jetpack Compose (Material 3)**, **Gradle Wrapper**, and automated **GitHub Actions APK building** (`.github/workflows/build-apk.yml`).

## Project Specifications
- **Application ID**: `com.cricketmanager.app`
- **Min SDK**: 24 (Android 7.0)
- **Compile / Target SDK**: 35 (Android 15)
- **AGP**: 8.7.3 | **Kotlin**: 2.0.21 | **KSP**: 2.0.21-1.0.28 | **Room**: 2.6.1 | **Gradle**: 8.10.2
- **APK Output Path**: `app/build/outputs/apk/debug/app-debug.apk`
- **GitHub Actions Artifact Name**: `Cricket-Manager-Debug-APK`

---

## Build Installable APK Using Only Your Android Phone

### English Quick Steps
1. Extract `CricketManager-Android.zip` on your phone (make sure the `.github` folder is visible in your file manager).
2. Open [github.com/new](https://github.com/new) in Chrome and create a new repository (with default branch `main`).
3. Upload all extracted files and folders (including `.github/workflows/build-apk.yml`, `gradle/`, `gradlew`, and `app/`).
4. Open the **Actions** tab in your GitHub repository. The **Build Cricket Manager Debug APK** workflow runs automatically on push to `main` (or via **Run workflow**).
5. When finished, open the workflow run, scroll to **Artifacts**, download **Cricket-Manager-Debug-APK**, unzip it, and tap `app-debug.apk` to install.

### সহজ বাংলা নির্দেশনা (Android ফোন ব্যবহারকারীদের জন্য)
১. প্রথমে ডাউনলোড করা `CricketManager-Android.zip` ফাইলটি আপনার ফোনের Files অ্যাপ বা ZArchiver দিয়ে Extract (আনজিপ) করুন।
২. ফোল্ডারের ভেতরে `.github` নামক হিডেন ফোল্ডারটি দেখা যাচ্ছে কিনা নিশ্চিত করুন (ZArchiver বা Files অ্যাপে "Show hidden files" চালু রাখুন)।
৩. ফোনের Chrome ব্রাউজারে [github.com](https://github.com) খুলে লগইন করুন এবং একটি নতুন Repository তৈরি করুন।
৪. `uploading an existing file` অপশনে ট্যাপ করে আনজিপ করা ফোল্ডারের সব ফাইল ও ফোল্ডার আপলোড করে `Commit changes` করুন।
৫. Repository-র **Actions** ট্যাবে যান। সেখানে **Build Cricket Manager Debug APK** অটোমেটিক চলতে শুরু করবে।
৬. সবুজ টিক চিহ্ন এলে নিচে **Artifacts** সেকশন থেকে **Cricket-Manager-Debug-APK** ডাউনলোড করুন, আনজিপ করুন এবং `app-debug.apk` ফাইলটিতে ট্যাপ করে ফোনে ইনস্টল করুন।

---

### Method 2: Android Studio (Desktop)
1. Extract `CricketManager-Android.zip`.
2. Open **Android Studio** -> **Open** -> select the `CricketManager-Android` folder.
3. Wait for Gradle Sync (JDK 17, AGP 8.7.3, Kotlin 2.0.21, Room 2.6.1).
4. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
5. Output APK: `app/build/outputs/apk/debug/app-debug.apk`.

### Method 3: Command Line (Linux / macOS / Termux)
```bash
# Requires JDK 17 and Android SDK (or Termux openjdk-17 + gradle)
chmod +x gradlew
./gradlew testDebugUnitTest --no-daemon
./gradlew assembleDebug --no-daemon
```
Output APK: `app/build/outputs/apk/debug/app-debug.apk`.
